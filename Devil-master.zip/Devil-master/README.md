#### Thank You-🙏🏼

<p>
<img src="https://visitor-badge.laobi.icu/badge?page_id=HackerWaSi" alt="visitor badge"/>
</p>


Evil Devill (Devil FaceBook Hacking Tool)
                
**username** `hacker`
**password** `wasii`
<p align="center">
  <a href="http://mocrz.blogspot.com/">
    <img src="https://img.shields.io/badge/EvilDevil-Mocrz-lightgrey">
  </a> 
  <a href="https://github.com/evildevill/Devil/releases">
    <img src="https://img.shields.io/badge/release-v3.0.0-blue">
  </a>
  <a href="https://wikipedia.org/wiki/Shell_script">
    <img src="https://img.shields.io/badge/language-shell-green.svg">
 </a>
  <a href="https://github.com/evildevill/Devil">
      <img src="https://img.shields.io/badge/issue-0%20open-green">
  </a>
  <a href="https://github.com/evildevill/Devil/wiki">
      <img src="https://img.shields.io/badge/wiki-Devil-lightgrey">
 </a>
  <a href="https://twitter.com/hackerwasii">
    <img src="https://img.shields.io/badge/twitter-Hackerwasi-blue.svg">
 </a>
</p>

![Evil-Devil](https://github.com/evildevill/Devil/blob/master/ascets/Screenshot_2020-08-30-14-16-35.png)

***

# About Devil Tool

```
Facebook tools keep getting more and more accessible to beginners, and the Devil Tool 
is a framework of serious Facebook Accounts Grabhing tools that can be explored easily from within it. 
This powerful and simple tool can be used for everything from installing new add-ons to grabbing 
a Facebook Accounts in a matter of seconds. Plus, it's easy to install, set up, and utilize.
```

***

# Getting started

## System requirements 

* Devil Framework only supports two OS.

```
Devil Framework only supports two 
operating systems - Kali Linux and Termux!
```


## Devil Tool installation

```
> apt-get update -y

> apt-get install python2 -y

> pip2 install mechanize

> pip2 install requests

> apt-get install git -y

> git clone https://github.com/evildevill/Devil.git

> cd Devil

> chmod +x *

> python2 wasi.py 

```

```
Also, we do not recommend to change the source code of ehtools because 
it is very complex and you can mess up something and disrupt the framework!
```

***

# Devil Framework execution

```
To run Devil Framework you should 
execute the following command.
```

> python2 Devil.py

***

# Why Devil Framework

* More than 38 tools for pentesting installed by default.

```
More than 38 options installed by default 
you can find in Devil, this is tools such 
as MetaSploit, Pupy and other tools!
```

* Password protection and config encryption.

```
In version 2.1.6 we added pasword protection, we added 
it for users who think that his/her friend or parents will 
turn into Devil and will remove or destroy it. Only for this 
people we created Devil Framework password protection.
```





# SubScribe Our YouTube Channel

<a href="https://www.youtube.com/channel/UC0bX56PZ_nMZw3t4p90SYyQ">
<p><img src="https://img.shields.io/badge/YouTube-TheLinuxChoice-blue.svg"></p>
</a>


![devil-yellow](https://github.com/evildevill/Devil/blob/master/ascets/youtube%20channel.png)

# Devil Framework disclaimer

```
Usage of the Devil Framework for attacking targets without prior mutual consent is illegal.
It is the end user's responsibility to obey all applicable local, state, federal, and international laws.
Developers assume no liability and are not responsible for any misuse or damage caused by this program.
```
